# Structured LLM Prompt Pipeline & JSON Extractor

Beginner-friendly Python project to extract invoice or resume information from plain text using OpenAI or Google Gemini, then validate the result with Pydantic.

## Features
- OpenAI and Gemini provider support
- Parameterized prompts and few-shot examples
- Invoice and resume Pydantic schemas
- Rejects unexpected fields and invalid data types
- Prints JSON or saves it to a file
- Missing values are `null` or empty lists, never guessed

## Setup (Windows)
1. Install Python 3.10 or newer.
2. Open Command Prompt in this folder.
3. Run:

```bash
py -m venv .venv
.venv\\Scripts\\activate
python -m pip install -r requirements.txt
copy .env.example .env
```

4. Open `.env` and add the API key for your provider. Do not share this file or upload it to GitHub.

## Run examples

OpenAI invoice:
```bash
python main.py --type invoice --provider openai --input sample_invoice.txt --output invoice.json
```

Gemini resume:
```bash
python main.py --type resume --provider gemini --input sample_resume.txt --output resume.json
```

To print output directly, omit `--output`. If `--input` is omitted, the program reads text from standard input.

## Pipeline
1. Read source text.
2. Build a prompt using the selected document type, JSON schema, and few-shot example.
3. Call the selected LLM API.
4. Parse the JSON response.
5. Validate it using Pydantic.
6. Print or save the validated JSON.

## Files
- `main.py`: complete application
- `requirements.txt`: Python dependencies
- `.env.example`: API-key configuration template
- `sample_invoice.txt`, `sample_resume.txt`: test inputs

## Important
This starter version accepts plain text, not scanned PDF/image files. Add OCR before the prompt step if you need scanned documents. Pydantic validates structure and types, not factual correctness; manually review important records. API usage may cost money.
