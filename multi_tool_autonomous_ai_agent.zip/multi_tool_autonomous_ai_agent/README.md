# Multi-Tool Autonomous AI Agent

A beginner-friendly console AI agent built with LangChain and OpenAI tool calling. It can decide when to use web search, a safe Python calculator, and a local text-file reader.

## Features
- **Web search:** DuckDuckGo search for current public information.
- **Calculator:** arithmetic with a restricted Python AST parser (does not use `eval`).
- **Local file reader:** reads UTF-8 text files only from the project's `workspace/` folder.
- **Autonomous tool selection:** the LLM chooses one or more tools based on the user's request.
- **Visible execution trace:** displays tool action names and tool observations, followed by the final answer.

## Requirements
- Python 3.10+
- OpenAI API key
- Internet access

## Setup on Windows

Open Command Prompt or the VS Code terminal in this folder:

```bash
py -m venv .venv
.venv\\Scripts\\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
copy .env.example .env
```

Edit `.env` and replace the placeholder with your OpenAI API key. Keep `.env private; do not upload it to GitHub.

## Run

```bash
python main.py
```

Then try these prompts:

1. `Search the web for the latest Python release and summarize the result.`
2. `Calculate (1250 * 3) + (1250 * 0.18).`
3. `Read notes.txt and summarize the services mentioned.`
4. `Search for the current population of Unnao, then calculate 10 percent of the figure.`
5. `Read notes.txt and calculate how many services are listed.`

Type `exit` to close the agent.

## Add your own files

Place `.txt` files inside `workspace/`, then ask the agent to read them by filename. The reader blocks path traversal and will not read files outside `workspace/`. It supports UTF-8 text files up to 1 MB.

## How it works

1. The user enters a request.
2. LangChain sends the request and tool descriptions to the model.
3. The model chooses a tool and supplies its arguments.
4. Python executes the selected tool.
5. The tool result (observation) is returned to the model.
6. The model may call another tool or produce a final answer.

The console displays action and observation summaries. It does not expose private internal reasoning.

## Troubleshooting

- **OPENAI_API_KEY missing:** check that `.env` exists and contains a valid key.
- **Package import errors:** activate `.venv` and rerun `pip install -r requirements.txt`.
- **Search errors:** check your internet connection; DuckDuckGo may temporarily rate-limit requests.
- **Model errors:** check API billing, key permissions, and the model name in `.env`.

## Security notes

- Never commit `.env` or share your API key.
- Only use the file-reader tool with documents you are authorized to access.
- Web results and file contents are untrusted input. The agent is instructed not to treat them as commands.
- The calculator supports numeric literals, parentheses, and `+ - * / // % **`; it does not execute arbitrary Python code.
- The project needs an API key and network access; API calls may incur charges.
